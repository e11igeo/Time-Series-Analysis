rm(list=ls())
#dev.off()

D <- read.table("A1_co2.txt", header = TRUE, sep = "")

# Subset containing the first 718 observations(for model estimation)
D_model <- subset(D, year <= 2017)

# Subset containing the last 20 observations (for validation)
D_test <- subset(D, year >= 2018)

t_model<-as.matrix(D_model$time)
yt_model<-as.matrix(D_model$co2)

t_test <-as.matrix(D_test$time)
yt_test<-as.matrix(D_test$co2)

n_model <- length(t_model)
n_test <- length(t_test)

p<-12

#1.1#####################################################

plot(yt_model ~ t_model, type = "l", 
     main = "CO2 concentration over time",
     xlab = "Time (years)", ylab = "CO2 concentration (ppm)",
     col = "blue",
     cex.lab = 1.5, cex.axis = 1.2, cex.main = 1.8)  
# Add color and line style
lines(yt_test ~ t_test, type = "l", col = "red", lty = 2)  

legend("bottomright", legend = c("Model Data", "Test Data"),
       col = c("blue", "red"),
       lty = c(1, 2), cex = 1.2)

#1.2.1################################################
# calculating values for p=12
x_ls<-cbind(1, t_model, sin(2*pi*t_model / as.numeric(p)),
            cos(2*pi*t_model / as.numeric(p)))
(ols <- solve (t(x_ls) %*% x_ls) %*% (t(x_ls) %*% yt_model))
# calculating values for p=1
x_ls1<-cbind(1, t_model, sin(2*pi*t_model), 
             cos(2*pi*t_model))
(ols1 <- solve (t(x_ls1) %*% x_ls1) %*% (t(x_ls1) %*% yt_model))

#1.2.2#################################################
# calculating values for p=12
S_ols<-t(yt_model-(x_ls%*%ols))%*%(yt_model-
              (x_ls%*%ols))/(n_model-4)
Var_ols<- as.numeric(S_ols) * solve(t(x_ls) %*% x_ls)
# calculating values for p=1
S_ols1<-t(yt_model-(x_ls1%*%ols1))%*%(yt_model-
                      (x_ls1%*%ols1))/(n_model-4)
Var_ols1<- as.numeric(S_ols1) * solve(t(x_ls1) %*% x_ls1)

#1.2.3########################################################
# calculating values for p=12
fit <- lm(yt_model ~ t_model + 
      sin(2*pi*t_model / as.numeric(p))
          + cos(2*pi*t_model / as.numeric(p)), data = D_model)
coef(fit)
summary(fit)

fit_test <- lm(yt_test ~ t_test + 
                sin(2*pi*t_test / as.numeric(p)) 
               + cos(2*pi*t_test / as.numeric(p)), 
            data = D_test)
x_olst <- data.frame(cbind(1, t_test,
                  sin(2*pi*t_test /as.numeric(p)),
                cos(2*pi*t_test / as.numeric(p))))
test_pred <- predict(fit_test, x_olst)

# calculating values for p=1
fit1 <- lm(yt_model ~ t_model + sin(2*pi*t_model)  +
             cos(2*pi*t_model),
           data = D_model)
coef(fit1)
summary(fit1)
fit_test1 <- lm(yt_test ~ t_test + sin(2*pi*t_test)
                + cos(2*pi*t_test), data = D_test)
x_olst1 <- data.frame(cbind(1, t_test, sin(2*pi*t_test), 
                            cos(2*pi*t_test)))
test_pred1 <- predict(fit_test1, x_olst1)


########################################better plot
# Set up the plot
plot(yt_model ~ t_model, D_model, col = "black",
     type = "l",
     xlab = "Time (years)", ylab = "CO2 (ppm)",
     main = "CO2 Concentrations Over Time")

# Add the fitted values and test data for p=1################
lines(fit1$fitted.values ~ t_model, col = "red",
      D_model, type = "l")
lines(test_pred1 ~ t_test, col = "blue", D_test,
      type = "l")

# Add a legend
legend("topleft", legend = c("Model Data",
                             "Fitted Values", "Test Data"),
       col = c("black", "red", "blue"), lty = 1, cex = 0.8)

# Add a title and subtitle
title(main = "CO2 Concentrations Over Time", 
      sub = "Model Fit and Test Predictions")

# Add gridlines to make it easier to read
grid()

# Customize the axis labels
axis(side = 1, at = seq(min(t_model),
                        max(t_test), by = 50), 
     labels = seq(min(t_model), max(t_test),
                  by = 50))
axis(side = 1, at = seq(300, 450, by = 75), 
     labels = seq(300, 450, by = 75))

# Add a background color
rect(par("usr")[1], par("usr")[3], par("usr")[2], 
     par("usr")[4], border = NA)

#1.2.5###############################################################
# the rest of the calculations are completed for p=12 as initialized
Sigma <- matrix(0, nrow(x_ls), nrow(x_ls))
rho <- 0.5

for(k in 1:5){
  for(i in 1:718){
    for(j in i:718){
      Sigma[i,j]<-rho^abs(i-j)
      Sigma[j,i]<-rho^abs(i-j)
    }
  }
  wls <-solve(t(x_ls)%*%solve(Sigma)%*%x_ls)%*%
    (t(x_ls)%*%solve(Sigma)%*%yt_model)  
  eps <- yt_model - x_ls%*%wls
  rho <- cor(eps[1:718-1],eps[2:718])
}

#1.2.6##########################################################################

S_wls<-t(yt_model-(x_ls%*%wls))%*%solve(Sigma)%*%(yt_model-
                      (x_ls%*%wls))/(718-4)
# estimator of variance
Var_wls<- as.numeric(S_wls) * solve(t(x_ls) %*% x_ls)

#1.2.7##########################################################################

yt_wls <- x_ls %*% wls

fit_wls <- lm(yt_wls ~ t_model + sin(2*pi*t_model / 
                                       as.numeric(p)) 
              + cos(2*pi*t_model / as.numeric(p)),
              data = D_model)
coef(fit_wls)
summary(fit_wls)

# Define a color palette
colors <- c("#1f78b4", "#33a02c")

# Create the plot
plot(yt_model ~ t_model, D_model, col = colors[1],
     type = "l",
     xlab = "Time (years)", ylab = "CO2 (ppm)",
main = "CO2 Concentrations Over Time with Fitted Values",
     xlim = c(1958, 2025), ylim = c(300, 450))

# Add fitted values
lines(fit_wls$fitted.values ~ t_model, col = colors[2],
      lwd = 2)

# Add a legend
legend("bottomright", legend = c("Model Data", 
                                 "Fitted Values"),
       col = colors, lty = 1, cex = 1.2, lwd = 2)

# Add a title and subtitle
title(sub = "Weighted Least Squares Model Fit")

# Add gridlines
grid(lwd = 0.5, lty = "dotted", col = "gray")

# Customize the axis labels and ticks
axis(side = 1, at = seq(1960, 2020, by = 10), 
     labels = seq(1960, 2020, by = 10),
     lwd.ticks = 1, col.ticks = "gray")
axis(side = 2, at = seq(300, 400, by = 50),
     labels = seq(300, 400, by = 50), 
     lwd.ticks = 1, col.ticks = "gray")

# Save the plot
png("fitted_values.png", width = 700, height = 600, res = 120)
dev.off()
#1.3.1#####################################
lamda <- 0.9 

f<- function(j) rbind(1, j, sin(2*pi*j/as.numeric(p)), 
                      cos(2*pi*j/as.numeric(p))) 

L <- matrix(c(1, 0, 0, 0, 
              
              1, 1, 0, 0, 
              
              0, 0, cos(2*pi/as.numeric(p)), 
              sin(2*pi/as.numeric(p)), 
              
              0, 0, -sin(2*pi/as.numeric(p)), 
              cos(2*pi/as.numeric(p))), 
            
            nrow = 4, byrow = TRUE) 
LInv <- solve(L)

#1.3.2##########################################################


init <- 10

F <- matrix(0, nrow=4, ncol=4)
h <- matrix(0,nrow=4,ncol=1)
Τ <- 0
theta.all <- matrix(NA,ncol=4, nrow=n_model)
sigma.all <- matrix(NA, nrow=n_model, ncol=1)
sd.theta.all <- matrix(NA,ncol=4, nrow=n_model)
yt_pred.all <- rep(NA, n_model)

sigma_el <- c()

t.smth <- qt(p=0.95, df=(1:n_model)-4)
t.smth[1:init] <- NA
yt_pr.u.all <- rep(NA, n_model)
yt_pr.l.all <- rep(NA, n_model)



for (j in 0:(init-1)){
  
  F <- F + (lamda^(j))*f(-j)%*%t(f(-j))
  h <- h + (lamda^(j))*f(-j)*yt_model[init-j]
  T <- T + lamda^j
  sigma_el <- c(sigma_el, lamda^(init-j-1))
 
}
Sigma_ltm <- diag(sigma_el)



theta.hat <- solve(F, h)
theta.all[init,] <- solve(F, h)
yt_pred.all[init+1] <- t(f(1)) %*% theta.hat


for (i in (init+1):n_model){
  
  F <- F + (lamda^(i-1))*f(- (i-1)) %*% t(f(- (i-1)))
  h <- lamda*solve(L) %*% h + f(0)*yt_model[i]
  T <- 0
  sigma_el <- c()
  for (j in 0:(i-1)){
    T <- T + lamda^j
    sigma_el <- append(sigma_el, lamda^(i-j-1))
  }
  Sigma_ltm <- diag(sigma_el)
  theta.hat <-  solve(F, h)
  theta.all[i,] <- theta.hat
  epsilon <- yt_model[1:i] - cbind(1, -(i-1):0, 
        sin(2*pi*(-(i-1):0)/p),
        cos(2*pi*(-(i-1):0)/p)) %*% theta.hat
sigma.all[i] <- sqrt((t(epsilon)%*% Sigma_ltm %*% epsilon)/
                         (T-4))
  yt_pred.all[i+1] <- t(f(1)) %*% theta.hat
  yt_pr.l.all[i+1] <- yt_pred.all[i+1] - 
t.smth[i]*sigma.all[i]*sqrt(1+t(f(1)) %*% solve(F) %*% f(1))
yt_pr.u.all[i+1] <- yt_pred.all[i+1] +
t.smth[i]*sigma.all[i]*sqrt(1+t(f(1)) %*% solve(F) %*% f(1))
  
}



#133#########################################################

plot(yt_model-yt_pred.all[1:718]~t_model)

# Set plot margins
par(mar = c(5, 4, 4, 6) + 0.1)

# Create x-axis tick marks and labels
years <- seq(1980, 2021, by = 5)
xticks <- as.numeric(as.Date(paste(years, "-01-01", sep = "")))
xticklabels <- as.character(years)

# Create plot
plot(yt_model[11:728] - yt_pred.all[11:728], 
     type = "l", 
     ylab = "One Step Prediction Error", 
     xlab = "Year",
     xtick = xticks,
     xticklabels = xticklabels)

# Add line for estimated sigma
lines(sigma.all[11:728], col = "red")

# Add legend
legend("bottomright", 
       legend = c("One Step Prediction Error", 
                  "Estimate of Sigma"), 
       col = c("black", "red"), 
       lty = 1, cex=0.8)

#####1.3.4.

# Set plot parameters
par(mar = c(5, 4, 4, 4))

# Plot data with one-step prediction and 95% prediction interval
plot(yt_model ~ t_model, 
     type = "l", 
     lwd = 2, 
     col = "black", 
     xlab = "Observation", 
     ylab = "Value", 
     main = "One Step Prediction with 95% Prediction Interval")

# Add lines for one-step prediction and prediction interval
lines(yt_pred.all[1:718] ~ t_model, 
      col = "red", 
      lwd = 2, 
      lty = "dashed")
lines(yt_pr.u.all[1:718] ~ t_model, 
      col = "blue", 
      lwd = 1, 
      lty = "dotted")
lines(yt_pr.l.all[1:718] ~ t_model, 
      col = "blue", 
      lwd = 1, 
      lty = "dotted")

# Add legend
legend("topleft",
       legend = c("Data", "One-step Prediction", 
                  "95% Prediction Interval"),
       lty = c(1, 2, 3),
       lwd = c(2, 2, 1),
       col = c("black", "red", "blue"))


#####1.3.5

init <- 10

D2010 <- subset(D, year >= 2010)

t <- as.matrix(D2010$time)
y <- as.matrix(D2010$co2)
n <- length(t)

F1 <- matrix(0, nrow=4, ncol=4)
h1 <- matrix(0,nrow=4,ncol=1)
T1 <- 0
theta.all1 <- matrix(NA,ncol=4, nrow=n)
sigma.all1 <- matrix(NA, nrow=n, ncol=1)
#sd.theta.all <- matrix(NA,ncol=4, nrow=n_model)
yt_pred.all1 <- rep(NA, n)

sigma_el1 <- c()

t.smth1 <- qt(p=0.95, df=(1:n)-4)
t.smth1[1:init] <- NA
yt_pr.u.all1 <- rep(NA, n)
yt_pr.l.all1 <- rep(NA, n)

for (j in 0:(init-1)){
  #browser()
  F1 <- F1 + (lamda^(j))*f(-j)%*%t(f(-j))
  h1 <- h1 + (lamda^(j))*f(-j)*y[init-j]
  T1 <- T1 + lamda^j
  sigma_el1 <- c(sigma_el1, lamda^(init-j-1))
}
Sigma_ltm1 <- diag(sigma_el1)

theta.hat1 <- solve(F1, h1)
theta.all1[init,] <- solve(F1, h1)
yt_pred.all1[init+1] <- t(f(1)) %*% theta.hat1

for (i in (init+1):n){
  F1 <- F1 + (lamda^(i-1))*f(-(i-1)) %*% t(f(-(i-1)))
  h1 <- lamda*solve(L) %*% h1 + f(0)*y[i]
  T1 <- 0
  sigma_el1 <- c()
  for (j in 0:(i-1)){
    T1 <- T1 + lamda^j
    sigma_el1 <- append(sigma_el1, lamda^(i-j-1))
  }
  Sigma_ltm1 <- diag(sigma_el1)
  theta.hat1 <-  solve(F1, h1)
  theta.all1[i,] <- theta.hat1
epsilon1 <- y[1:i] - cbind(1, -(i-1):0, sin(2*pi*(-(i-1):0)/p), 
     cos(2*pi*(-(i-1):0)/p)) %*% theta.hat1
sigma.all1[i] <- sqrt((t(epsilon1)%*% Sigma_ltm1 %*% epsilon1)/
                          (T1-4))
  yt_pred.all1[i+1] <- t(f(1)) %*% theta.hat1
  yt_pr.l.all1[i+1] <- yt_pred.all1[i+1] - 
t.smth[i]*sigma.all1[i]*sqrt(1+t(f(1)) %*% solve(F1) %*% f(1))
yt_pr.u.all1[i+1] <- yt_pred.all1[i+1] + 
t.smth[i]*sigma.all1[i]*sqrt(1+t(f(1)) %*% solve(F1) %*% f(1))
}


# set up plot area
par(mfrow=c(1,1), mar=c(5,5,4,2)+0.1)

# plot actual data
plot(y ~ t, type="l", lwd=2, col="black", xlab="Year",
     ylab="CO2 (ppm)", 
     ylim=c(390,420))

# add predicted values and prediction intervals
lines(yt_pred.all1[1:116]~t, col="red", lwd=2)
lines(yt_pr.u.all1[1:116]~t, col="blue", lty=2, lwd=2)
lines(yt_pr.l.all1[1:116]~t, col="blue", lty=2, lwd=2)

# add legend
legend("bottomright", 
       legend=c("Observed","Predicted",
                "95% Prediction Interval"), 
       lty=c(1,1,2), col=c("black","red","blue"), lwd=2,
       cex=0.8)

# add shaded area for test data
#rect(2010, 390, 2023, 420, col="gray", border=NA, alpha=0.2)

# add text for test data label
text(2015, 410, "Test Data", col="gray30", font=2, cex=0.8)

# add title and subtitle
title("Atmospheric CO2 Concentration Since 2010", font=2,
      cex.main=1.2)
mtext("Predictions and 95% Prediction Intervals", side=3, 
      line=-1, font=2,
      cex=0.9)






#############1.3.6    


yt_pred_month1 <- t(f(1)) %*% theta.hat
yt_pred_month2 <- t(f(2)) %*% theta.hat
yt_pred_month6 <- t(f(6)) %*% theta.hat
yt_pred_month12 <- t(f(12)) %*% theta.hat
yt_pred_month20 <- t(f(20)) %*% theta.hat

y_t_predictions <- matrix(c(yt_pred_month1,yt_pred_month2,
                       yt_pred_month6,yt_pred_month12,
                    yt_pred_month20))

months_ahead <- c(1,2,6,12,20)
prediction <- cbind( months_ahead, y_t_predictions)


# Plot the matrix with custom colors

plot(prediction)
#############1.3.7
y_part <- matrix(c(yt_pred.all1[n-20+1], 
              yt_pred.all1[n-20+2], 
             yt_pred.all1[n-20+6], 
             yt_pred.all1[n-20+12],
                   yt_pred.all1[n-20+20]))
prediction_part <- cbind(months_ahead, y_part)

#############1.3.7
y_part <- matrix(c(yt_pred.all1[n-20+1],
                   yt_pred.all1[n-20+2],
                   yt_pred.all1[n-20+6],
                   yt_pred.all1[n-20+12],
                   yt_pred.all1[n-20+20]))
prediction_part <- cbind(months_ahead, y_part)

plot(prediction, 
main="Predictions Months Ahead Compared with Test Data",
     xlab="time(months)", ylab="Co2(ppm)")
points(prediction_part, col="red", pch=16)
legend("bottomright", c("Multi step predictions", 
                        "One step predictions"),
       col=c("red", "black"), pch=c(16, NA))



# Question 1.3.8 
Y <- D_model$co2

F <- matrix(0, nrow=4, ncol=4)
h <- matrix(0,nrow=4,ncol=1)
init <-10
lambda <- 0.9
n = length(Y)

# Burning - 3.100
for (j in 0:(init-1)){
  
  F <- F + lambda^(j) * f(-j)%*%t(f(-j))
  h <- h + lambda^(j) * f(-j)*Y[init-j]
}

theta_local <- matrix(0, nrow=718, ncol=4)

# UPDATING - Local trend - Formula (3.104)
for (j in (init+1):n){
  
F <- F + lambda^(j-1) * f(-(j-1)) %*% t(f(-(j-1)))
h <- lambda * solve(L) %*% h + f(0) * Y[j]
  theta_hat_local <- solve(F) %*% h
  theta_local[j,] <- theta_hat_local
}

p=12

# flip X and negate it
t_rev <- 717:0
X_local1 <- cbind(1, t_rev,
              sin(2*(pi*t_rev)/p), 
             cos(2*(pi*t_rev)/p) )
y_hat_local <- X_local1 %*% theta_hat_local
y_hat_local_1step <- rep(0, n=718)

errors <- matrix(0, nrow=718, ncol=1)

for (i in 1:718){
  # Predicting - Local trend - Formula 3.105
y_hat_local[i] <- X_local1[i,] %*% t(theta_local[i,])
  
  # One step error
  if(i>10){
y_hat_local_1step[i] <- X_local1[i,] %*% t(theta_local[i-1,])
errors[i] <- Y[i] - X_local1[i,] %*% t(theta_local[i-1,])
  }
}


plot(D_model$time, errors,type="p",
main="Errors for the estimated mean for each time step",
xlab="Time (years)",ylab="error",col="red", pch=19, cex= 0.1)

#######################plot estimated mean for each time step
plot(D_model$time, D_model$co2, type = "p", 
main = "Estimated mean for each time step",
xlab = "Time (years)", ylab = "Atmospheric CO2 [ppm]", 
col = "red", pch = 19, cex = 0.1)
lines(D_model$time, y_hat_local, type = "p", 
      col = "blue", pch = 19, 
      cex = 0.1 )



####1.4.1
#First we define the SSE

SSE = c()

Y_obs <- D_model$co2

#Getting into the loop for lamda from 0 to 1 with step 0.01

for (lamda_opt in seq(0.01,1,by=0.01)){
  
  p = 12
  L = matrix(c(1,1,0,0, 0,1,0,0, 0,0,cos(2*pi/p),
               -sin(2*pi/p),
               0,0,sin(2*pi/p), 
               cos(2*pi/p) ), nrow=4, ncol=4)
  
  f <- function(j) rbind(1, j, sin((2*pi/p)*j),
                         cos((2*pi/p)*j)) 
  F <- matrix(0, nrow=4, ncol=4)
  h <- matrix(0,nrow=4,ncol=1)
  
  init <- 100
  
  # Burning the first 100 observations
  
  F <- matrix(0, nrow = 4, ncol = 4)
  
  for (j in 0:(init-1)) {
    F <- F + lamda_opt^j * f(-j) %*% t(f(-j))
  }
  
  h <- 0
  
  for (j in 0:(init-1)) {
    h <- h + lamda_opt^j * f(-j) * Y_obs[init-j]
  }
  
  theta.hat <- solve(F)%*%h
  Y_pred <- rep(0,718)
  
  
  
  # Working on the left observations of training set 
  
  for (N in (init+1):718){
    
    Y_pred[N] <- t(f(1)) %*% theta.hat 
    F <- F + lamda_opt^(N-1) * f(-N+1) %*% t(f(-N+1))
    h <- lamda_opt * solve(L) %*% h + f(0) %*% Y_obs[N]
    theta.hat <- solve(F) %*% h
  }
  
  SSE =c(SSE,sum(abs(Y_obs-Y_pred)^2))
  
}



# Find the index of the minimum value of SSE which is the optimal lamda

min_index <- which.min(SSE)
lamda_opt<- min_index/100

# Plot SSE against lamda_opt

plot(seq(0.01, 1, by = 0.01), SSE, type = "l",
     main = "Optimal lamda",
     xlab = "lamda", ylab = "S(lamda)")

# Add a red point at the minimum point
points(seq(0.01, 1, by = 0.01)[min_index], 
       SSE[min_index], col = "red", 
       pch = 19)


lamda <- lamda_opt

f<- function(j) rbind(1, j, sin(2*pi*j/as.numeric(p)),
                      cos(2*pi*j/as.numeric(p))) 

L <- matrix(c(1, 0, 0, 0, 
              
              1, 1, 0, 0, 
              
              0, 0, cos(2*pi/as.numeric(p)),
              sin(2*pi/as.numeric(p)), 
              
              0, 0, -sin(2*pi/as.numeric(p)),
              cos(2*pi/as.numeric(p))), 
            
            nrow = 4, byrow = TRUE) 
LInv <- solve(L)

init <- 10

F <- matrix(0, nrow=4, ncol=4)
h <- matrix(0,nrow=4,ncol=1)
Τ <- 0
theta.all <- matrix(NA,ncol=4, nrow=n_model)
sigma.all <- matrix(NA, nrow=n_model, ncol=1)
sd.theta.all <- matrix(NA,ncol=4, nrow=n_model)
yt_pred.all <- rep(NA, n_model)
#error <- rep(NA, n_model)

#sd <- rep(NA, n_model)
#sse <- rep(NA, n_model)
#sigma2 <- rep(NA, n_model)
#sigma_el <- rep(NA, )
sigma_el <- c()

t.smth <- qt(p=0.95, df=(1:n_model)-4)
t.smth[1:init] <- NA
yt_pr.u.all <- rep(NA, n_model)
yt_pr.l.all <- rep(NA, n_model)

#sigma.all1 <- matrix(NA, nrow=n_model, ncol=1)
#yt_pred1 <- rep(NA, n_model)
#error1 <- rep(NA, n_model)

for (j in 0:(init-1)){
  #browser()
  F <- F + (lamda^(j))*f(-j)%*%t(f(-j))
  h <- h + (lamda^(j))*f(-j)*yt_model[init-j]
  T <- T + lamda^j
  sigma_el <- c(sigma_el, lamda^(init-j-1))
  
}
Sigma_ltm <- diag(sigma_el)


theta.hat <- solve(F, h)
theta.all[init,] <- solve(F, h)
yt_pred.all[init+1] <- t(f(1)) %*% theta.hat


for (i in (init+1):n_model){
  #browser()
  F <- F + (lamda^(i-1))*f(- (i-1)) %*% t(f(- (i-1)))
  h <- lamda*solve(L) %*% h + f(0)*yt_model[i]
  T <- 0
  sigma_el <- c()
  for (j in 0:(i-1)){
    T <- T + lamda^j
    sigma_el <- append(sigma_el, lamda^(i-j-1))
  }
  Sigma_ltm <- diag(sigma_el)
  theta.hat <-  solve(F, h)
  theta.all[i,] <- theta.hat
  epsilon <- yt_model[1:i] - cbind(1, -(i-1):0, 
              sin(2*pi*(-(i-1):0)/p), 
             cos(2*pi*(-(i-1):0)/p)) %*% theta.hat
sigma.all[i] <- sqrt((t(epsilon)%*% Sigma_ltm %*% epsilon)/
                         (T-4))
  yt_pred.all[i+1] <- t(f(1)) %*% theta.hat
  yt_pr.l.all[i+1] <- yt_pred.all[i+1] - 
t.smth[i]*sigma.all[i]*sqrt(1+t(f(1)) %*% solve(F) %*% f(1))
yt_pr.u.all[i+1] <- yt_pred.all[i+1] + 
t.smth[i]*sigma.all[i]*sqrt(1+t(f(1)) %*% solve(F) %*% f(1))
 
}

plot(yt_model-yt_pred.all[1:718]~t_model)



plot(yt_model[11:728]-yt_pred.all[11:728], type="l", 
     ylab="One Step Prediction Error", xlab="Observation")
lines(sigma.all[11:728], col="red")
legend("topright", legend=c("One Step Prediction Error", 
                            "Estimate of Sigma"),
       col=c("black", "red"), lty=1)

# Set plot margins
par(mar = c(5, 4, 4, 6) + 0.1)

# Create plot
plot(yt_model[11:728] - yt_pred.all[11:728], 
     type = "l", 
     ylab = "One Step Prediction Error", 
     xlab = "Observation")

# Add line for estimated sigma
lines(sigma.all[11:728], col = "red")

# Add legend
legend("topright", 
       legend = c("One Step Prediction Error", 
                  "Estimate of Sigma"), 
       col = c("black", "red"), 
       lty = 1)


init <- 10

D2010 <- subset(D, year >= 2010)

t <- as.matrix(D2010$time)
y <- as.matrix(D2010$co2)
n <- length(t)

F1 <- matrix(0, nrow=4, ncol=4)
h1 <- matrix(0,nrow=4,ncol=1)
T1 <- 0
theta.all1 <- matrix(NA,ncol=4, nrow=n)
sigma.all1 <- matrix(NA, nrow=n, ncol=1)
#sd.theta.all <- matrix(NA,ncol=4, nrow=n_model)
yt_pred.all1 <- rep(NA, n)

sigma_el1 <- c()

t.smth1 <- qt(p=0.95, df=(1:n)-4)
t.smth1[1:init] <- NA
yt_pr.u.all1 <- rep(NA, n)
yt_pr.l.all1 <- rep(NA, n)

for (j in 0:(init-1)){
  #browser()
  F1 <- F1 + (lamda^(j))*f(-j)%*%t(f(-j))
  h1 <- h1 + (lamda^(j))*f(-j)*y[init-j]
  T1 <- T1 + lamda^j
  sigma_el1 <- c(sigma_el1, lamda^(init-j-1))
}
Sigma_ltm1 <- diag(sigma_el1)

theta.hat1 <- solve(F1, h1)
theta.all1[init,] <- solve(F1, h1)
yt_pred.all1[init+1] <- t(f(1)) %*% theta.hat1

for (i in (init+1):n){
  F1 <- F1 + (lamda^(i-1))*f(-(i-1)) %*% t(f(-(i-1)))
  h1 <- lamda*solve(L) %*% h1 + f(0)*y[i]
  T1 <- 0
  sigma_el1 <- c()
  for (j in 0:(i-1)){
    T1 <- T1 + lamda^j
    sigma_el1 <- append(sigma_el1, lamda^(i-j-1))
  }
  Sigma_ltm1 <- diag(sigma_el1)
  theta.hat1 <-  solve(F1, h1)
  theta.all1[i,] <- theta.hat1
  epsilon1 <- y[1:i] - cbind(1, -(i-1):0, 
                  sin(2*pi*(-(i-1):0)/p), 
              cos(2*pi*(-(i-1):0)/p)) %*% theta.hat1
sigma.all1[i] <- sqrt((t(epsilon1)%*% Sigma_ltm1 %*% epsilon1)/
                          (T1-4))
  yt_pred.all1[i+1] <- t(f(1)) %*% theta.hat1
  yt_pr.l.all1[i+1] <- yt_pred.all1[i+1] -
t.smth[i]*sigma.all1[i]*sqrt(1+t(f(1)) %*% solve(F1) %*% f(1))
yt_pr.u.all1[i+1] <- yt_pred.all1[i+1] +
t.smth[i]*sigma.all1[i]*sqrt(1+t(f(1)) %*% solve(F1) %*% f(1))
}

# set up plot area
par(mfrow=c(1,1), mar=c(5,5,4,2)+0.1)

# plot actual data
plot(y ~ t, type="l", lwd=2, col="black", xlab="Year", 
     ylab="CO2 (ppm)", 
     ylim=c(390,420))

# add predicted values and prediction intervals
lines(yt_pred.all1[1:116]~t, col="red", lwd=2)
lines(yt_pr.u.all1[1:116]~t, col="blue", lty=2, lwd=2)
lines(yt_pr.l.all1[1:116]~t, col="blue", lty=2, lwd=2)

# add legend
legend("bottomright", legend=c("Observed","Predicted",
                               "95% Prediction Interval"),
       lty=c(1,1,2), col=c("black","red","blue"), lwd=2,
       cex=0.8)

# add shaded area for test data
#rect(2010, 390, 2023, 420, col="gray", border=NA, alpha=0.2)

# add text for test data label
text(2015, 410, "Test Data", col="gray30", font=2, cex=0.8)

# add title and subtitle
title("Atmospheric CO2 Concentration Since 2010 for 
      optimal lamda",
      font=2, cex.main=1.2)
mtext("Predictions and 95% Prediction Intervals", 
      side=3, line=-1,
      font=2, cex=0.9)




yt_pred_month1 <- t(f(1)) %*% theta.hat
yt_pred_month2 <- t(f(2)) %*% theta.hat
yt_pred_month6 <- t(f(6)) %*% theta.hat
yt_pred_month12 <- t(f(12)) %*% theta.hat
yt_pred_month20 <- t(f(20)) %*% theta.hat

y_t_predictions <- matrix(c(yt_pred_month1,
                            yt_pred_month2,
                            yt_pred_month6,
                            yt_pred_month12,
                            yt_pred_month20))

months_ahead <- c(1,2,6,12,20)
prediction <- cbind( months_ahead,
                     y_t_predictions)


plot(prediction)


y_part <- matrix(c(yt_pred.all1[n-20+1], 
                   yt_pred.all1[n-20+2], 
                   yt_pred.all1[n-20+6], 
                   yt_pred.all1[n-20+12], 
                   yt_pred.all1[n-20+20]))
prediction_part <- cbind(months_ahead, y_part)

plot(prediction)
points(prediction_part, col="red")

